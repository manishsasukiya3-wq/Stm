package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * TEST MITRA - SAFE SOUND FEATURE
 * 100% Application-local sound engine.
 * - SoundPool for fast zero-latency UI sounds
 * - Local audio synthesis / SoundPool with fallback so it works 100% offline
 * - Local SharedPreferences for Sound ON/OFF state (NO Supabase, NO Server)
 * - Duplicate sound prevention & overlap control
 */
class SoundManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private var soundEnabled: Boolean = prefs.getBoolean(KEY_SOUND_ENABLED, true)

    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<SoundType, Int>()

    private var lastClickTimestamp: Long = 0L
    private var isAppOpenPlayed: Boolean = false

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    enum class SoundType {
        CLICK,
        TEST_START,
        CORRECT,
        WRONG,
        SAVE,
        TEST_COMPLETE,
        ERROR
    }

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(audioAttributes)
            .build()

        // Initialize Text-To-Speech for pleasant "ટેસ્ટ મિત્ર" voice
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady = true
                    val guLocale = Locale("gu", "IN")
                    val hiLocale = Locale("hi", "IN")
                    if (tts?.isLanguageAvailable(guLocale) == TextToSpeech.LANG_AVAILABLE) {
                        tts?.language = guLocale
                    } else if (tts?.isLanguageAvailable(hiLocale) == TextToSpeech.LANG_AVAILABLE) {
                        tts?.language = hiLocale
                    }
                    tts?.setPitch(1.15f)
                    tts?.setSpeechRate(0.95f)
                }
            }
        } catch (_: Exception) {}
    }

    fun isEnabled(): Boolean = soundEnabled

    fun setSoundEnabled(enabled: Boolean) {
        soundEnabled = enabled
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
    }

    fun toggleSound(): Boolean {
        val next = !soundEnabled
        setSoundEnabled(next)
        if (next) {
            playButtonClick()
        }
        return next
    }

    /**
     * App Open Sound:
     * - Short pleasant educational welcome tune
     * - Soft voice announcement: "ટેસ્ટ મિત્ર"
     */
    fun playAppOpen() {
        if (!soundEnabled || isAppOpenPlayed) return
        isAppOpenPlayed = true

        // Play pleasant educational chime
        playToneSequence(
            floatArrayOf(261.63f, 329.63f, 392.00f, 523.25f), // C4, E4, G4, C5
            floatArrayOf(150f, 150f, 150f, 400f)
        )

        // Pleasant voice: "ટેસ્ટ મિત્ર"
        try {
            if (isTtsReady && tts != null) {
                tts?.speak("ટેસ્ટ મિત્ર", TextToSpeech.QUEUE_ADD, null, "TEST_MITRA_OPEN")
            }
        } catch (_: Exception) {}
    }

    /**
     * Button Click:
     * Short soft click (50ms).
     * Includes debounce to prevent double-click echo.
     */
    fun playButtonClick() {
        if (!soundEnabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastClickTimestamp < 70) return // Deduplicate
        lastClickTimestamp = now

        playShortTone(800f, 45, 0.25f)
    }

    /**
     * Test Start:
     * Short pleasant start sound.
     */
    fun playTestStart() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(440f, 554.37f, 659.25f), // A4, C#5, E5
            floatArrayOf(100f, 120f, 250f)
        )
    }

    /**
     * Correct Answer:
     * Short positive sound.
     */
    fun playCorrect() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(523.25f, 659.25f, 783.99f), // C5, E5, G5
            floatArrayOf(80f, 100f, 220f)
        )
    }

    /**
     * Wrong Answer:
     * Short soft error sound.
     */
    fun playWrong() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(280f, 220f),
            floatArrayOf(100f, 180f)
        )
    }

    /**
     * Save:
     * Short success sound.
     */
    fun playSave() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(587.33f, 880f), // D5, A5
            floatArrayOf(100f, 220f)
        )
    }

    /**
     * Test Completed:
     * Short completion celebratory fanfare.
     */
    fun playTestComplete() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(440f, 554.37f, 659.25f, 880f), // A4, C#5, E5, A5
            floatArrayOf(100f, 120f, 140f, 350f)
        )
    }

    /**
     * Error:
     * Short warning sound.
     */
    fun playError() {
        if (!soundEnabled) return
        playToneSequence(
            floatArrayOf(300f, 250f),
            floatArrayOf(90f, 120f)
        )
    }

    private fun playShortTone(frequency: Float, durationMs: Int, volume: Float = 0.3f) {
        Thread {
            try {
                val sampleRate = 22050
                val numSamples = (durationMs * sampleRate) / 1000
                val samples = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val envelope = exp(-3.0 * i / numSamples)
                    val value = (sin(2.0 * PI * frequency * t) * envelope * 32767 * volume).toInt()
                    samples[i] = value.coerceIn(-32768, 32767).toShort()
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(samples, 0, samples.size)
                audioTrack.play()
                SystemClock.sleep(durationMs.toLong() + 20)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {}
        }.start()
    }

    private fun playToneSequence(frequencies: FloatArray, durations: FloatArray) {
        Thread {
            try {
                val sampleRate = 22050
                var totalDurationMs = 0
                for (d in durations) totalDurationMs += d.toInt()
                val totalSamples = (totalDurationMs * sampleRate) / 1000
                val allSamples = ShortArray(totalSamples)

                var sampleOffset = 0
                for (step in frequencies.indices) {
                    val freq = frequencies[step]
                    val durMs = durations[step].toInt()
                    val count = (durMs * sampleRate) / 1000
                    for (i in 0 until count) {
                        val t = i.toDouble() / sampleRate
                        val envelope = exp(-2.5 * i / count)
                        val value = (sin(2.0 * PI * freq * t) * envelope * 32767 * 0.35f).toInt()
                        val writeIdx = sampleOffset + i
                        if (writeIdx < totalSamples) {
                            allSamples[writeIdx] = value.coerceIn(-32768, 32767).toShort()
                        }
                    }
                    sampleOffset += count
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(allSamples.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(allSamples, 0, allSamples.size)
                audioTrack.play()
                SystemClock.sleep(totalDurationMs.toLong() + 30)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {}
        }.start()
    }

    fun release() {
        try {
            soundPool.release()
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {}
    }

    companion object {
        private const val PREFS_NAME = "test_mitra_sound_prefs"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
    }
}
