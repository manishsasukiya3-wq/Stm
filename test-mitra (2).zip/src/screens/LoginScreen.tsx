import React, { useState } from 'react';
import { Phone, Lock, Eye, EyeOff, LogIn, AlertTriangle, GraduationCap } from 'lucide-react';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { User } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
}) => {
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSwitchDeviceDialog, setShowSwitchDeviceDialog] = useState(false);

  const handleLogin = async (forceSwitch: boolean = false) => {
    SoundManager.playButtonClick();
    const cleanMobile = mobileNumber.trim();
    const cleanPassword = password.trim();

    if (!cleanMobile) {
      SoundManager.playError();
      setErrorMessage('Please enter your mobile number');
      return;
    }
    if (!cleanPassword) {
      SoundManager.playError();
      setErrorMessage('Please enter your password');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    const result = await SupabaseManager.login(cleanMobile, cleanPassword, forceSwitch);
    setIsLoading(false);

    if (result.user) {
      SoundManager.playSave();
      localStorage.setItem('test_mitra_current_user', JSON.stringify(result.user));
      onLoginSuccess(result.user);
    } else if (result.isDeviceActiveOnAnotherPhone) {
      SoundManager.playError();
      setShowSwitchDeviceDialog(true);
    } else {
      SoundManager.playError();
      setErrorMessage(result.error || 'Login failed. Please check credentials.');
    }
  };

  return (
    <div className="min-h-screen w-full bg-slate-50 flex flex-col justify-center items-center p-4 selection:bg-blue-600 selection:text-white">
      {/* Container */}
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        {/* Header Ribbon */}
        <div className="bg-[#1E3A8A] p-6 text-center text-white relative">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mx-auto mb-3 shadow-md border-2 border-emerald-400 overflow-hidden relative">
            <img
              src="/icon-192.png"
              alt="Test Mitra"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <GraduationCap className="w-9 h-9 text-[#1E3A8A] absolute inset-0 m-auto -z-10" />
          </div>
          <h1 className="text-2xl font-black tracking-wide font-display">
            TEST MITRA
          </h1>
          <p className="text-emerald-300 text-xs font-bold tracking-wider uppercase mt-1">
            Online MCQ Test Portal
          </p>
        </div>

        {/* Form Body */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleLogin(false);
          }}
          className="p-6 sm:p-8 space-y-5"
        >
          <div>
            <h2 className="text-lg font-bold text-slate-900">Login to Your Account</h2>
            <p className="text-xs text-slate-500 mt-0.5">Enter your registered mobile & password</p>
          </div>

          {/* Mobile Number Field */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Mobile Number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4 text-[#1E3A8A]" />
              </div>
              <input
                type="tel"
                value={mobileNumber}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                  setMobileNumber(val);
                  setErrorMessage(null);
                }}
                placeholder="10-digit mobile number"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl py-3 pl-10 pr-4 text-sm text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] transition-all"
                required
              />
            </div>
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4 text-[#1E3A8A]" />
              </div>
              <input
                type={isPasswordVisible ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMessage(null);
                }}
                placeholder="Enter password"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl py-3 pl-10 pr-10 text-sm text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] transition-all"
                required
              />
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setIsPasswordVisible(!isPasswordVisible);
                }}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
              >
                {isPasswordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs font-semibold text-red-600">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-3.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 active:scale-[0.98] disabled:opacity-50 cursor-pointer"
          >
            {isLoading ? (
              <div className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white animate-spin" />
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Login</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Switch Device Modal */}
      {showSwitchDeviceDialog && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Account Active on Another Device
              </h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              This student account is currently active on another device.
              <br /><br />
              If you switched to this phone or reinstalled the app, you can activate this device now as your single active session.
            </p>
            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowSwitchDeviceDialog(false);
                  handleLogin(true);
                }}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs shadow transition-all cursor-pointer"
              >
                Activate on This Device
              </button>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowSwitchDeviceDialog(false);
                }}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
