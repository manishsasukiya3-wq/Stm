import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  ArrowLeft,
  ArrowRight,
  Send,
  X,
  AlertTriangle,
  ZoomIn,
  BookOpen,
} from 'lucide-react';
import { SoundManager } from '../services/soundManager';
import { SupabaseManager } from '../services/supabaseClient';
import { User, QuestionItem } from '../types';

interface TakeTestScreenProps {
  testId: number;
  testName: string;
  durationMinutes: number;
  user: User;
  onTestFinished: (
    testId: number,
    testName: string,
    totalQuestions: number,
    correctCount: number,
    score: number,
    answersMapJson: string
  ) => void;
  onCancelTest: () => void;
}

export const TakeTestScreen: React.FC<TakeTestScreenProps> = ({
  testId,
  testName,
  durationMinutes,
  user,
  onTestFinished,
  onCancelTest,
}) => {
  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Map<number, string>>(new Map());
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Modals
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);
  const [zoomedImageUrl, setZoomedImageUrl] = useState<string | null>(null);
  const [submitErrorMessage, setSubmitErrorMessage] = useState<string | null>(null);

  // Timer
  const totalSeconds = useMemo(() => (durationMinutes > 0 ? durationMinutes : 15) * 60, [durationMinutes]);
  const [remainingSeconds, setRemainingSeconds] = useState(totalSeconds);

  // Load questions
  useEffect(() => {
    const fetchQuestions = async () => {
      setIsLoading(true);
      setErrorMessage(null);
      const res = await SupabaseManager.getQuestionsForTest(testId);
      if (res.error) {
        setErrorMessage(res.error);
      } else {
        setQuestions(res.questions);
      }
      setIsLoading(false);
    };
    fetchQuestions();
  }, [testId]);

  // Timer countdown
  useEffect(() => {
    if (isLoading || questions.length === 0 || isSubmitting) return;

    const interval = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleFinalSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isLoading, questions.length, isSubmitting]);

  const handleSelectOption = (qId: number, optionLetter: string) => {
    SoundManager.playButtonClick();
    setSelectedAnswers((prev) => {
      const next = new Map(prev);
      next.set(qId, optionLetter);
      return next;
    });
  };

  const handleClearSelection = (qId: number) => {
    SoundManager.playButtonClick();
    setSelectedAnswers((prev) => {
      const next = new Map(prev);
      next.delete(qId);
      return next;
    });
  };

  const handlePrev = () => {
    SoundManager.playButtonClick();
    if (currentIndex > 0) setCurrentIndex((i) => i - 1);
  };

  const handleNext = () => {
    SoundManager.playButtonClick();
    if (currentIndex < questions.length - 1) setCurrentIndex((i) => i + 1);
  };

  const handleFinalSubmit = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setSubmitErrorMessage(null);

    // Calculate score
    let correctCount = 0;
    const answersObj: Record<string, string> = {};

    questions.forEach((q) => {
      const qId = q.id || 0;
      const chosen = selectedAnswers.get(qId) || '';
      answersObj[String(qId)] = chosen;

      const correctOpt = (q.correct_option || '').trim().toUpperCase().charAt(0);
      if (chosen && chosen.toUpperCase() === correctOpt) {
        correctCount++;
      }
    });

    const finalScore = correctCount;
    const answersJson = JSON.stringify(answersObj);

    if (user.id) {
      const res = await SupabaseManager.submitResult(user.id, testId, finalScore);
      if (res.error) {
        setIsSubmitting(false);
        SoundManager.playError();
        setSubmitErrorMessage(res.error || 'Failed to save test result to Supabase.');
        return;
      }
    }

    // Play Special Action Sound: Test Complete fanfare!
    SoundManager.playTestComplete();
    setIsSubmitting(false);

    onTestFinished(
      testId,
      testName,
      questions.length,
      correctCount,
      finalScore,
      answersJson
    );
  };

  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  const isUrgent = remainingSeconds <= 120; // 2 minutes

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center space-y-3">
        <div className="w-9 h-9 rounded-full border-3 border-blue-200 border-t-[#1E3A8A] animate-spin" />
        <p className="text-sm font-semibold text-slate-700">Loading test questions...</p>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 max-w-md w-full space-y-3">
          <p className="text-sm font-bold text-red-600">{errorMessage}</p>
          <button
            onClick={onCancelTest}
            className="px-4 py-2 bg-[#1E3A8A] text-white text-xs font-bold rounded-xl shadow cursor-pointer"
          >
            Back to Tests
          </button>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-8 max-w-sm w-full space-y-3 shadow-xs">
          <h3 className="text-base font-bold text-slate-900">No Questions Available</h3>
          <p className="text-xs text-slate-500">There are no questions in this test yet.</p>
          <button
            onClick={onCancelTest}
            className="w-full bg-[#1E3A8A] text-white text-xs font-bold py-2.5 rounded-xl shadow cursor-pointer"
          >
            Back to Tests
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const qId = currentQ.id || 0;
  const selectedOpt = selectedAnswers.get(qId);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 bg-[#1E3A8A] text-white shadow-md safe-top-header">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          {/* Exit Button + Test Title */}
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                setShowExitModal(true);
              }}
              title="Exit Test"
              className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-blue-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-bold text-white truncate">
                {testName}
              </h1>
              <p className="text-xs text-blue-200 font-medium">
                Question {currentIndex + 1} of {questions.length}
              </p>
            </div>
          </div>

          {/* Timer Display */}
          <div
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black tracking-wider transition-colors shadow-xs ${
              isUrgent ? 'bg-red-600 text-white animate-pulse' : 'bg-emerald-600 text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span className="font-mono">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-blue-950/40 h-1.5 overflow-hidden">
          <div
            className="bg-emerald-400 h-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>
      </header>

      {/* Question Navigation Palette */}
      <div className="bg-white border-b border-slate-200 shadow-xs overflow-x-auto py-2.5 px-4 scrollbar-none">
        <div className="max-w-4xl mx-auto flex items-center gap-2">
          {questions.map((q, idx) => {
            const thisQId = q.id || 0;
            const isAnswered = selectedAnswers.has(thisQId);
            const isCurrent = idx === currentIndex;

            return (
              <button
                key={thisQId || idx}
                onClick={() => {
                  SoundManager.playButtonClick();
                  setCurrentIndex(idx);
                }}
                className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all flex-shrink-0 cursor-pointer ${
                  isCurrent
                    ? 'bg-[#1E3A8A] text-white ring-2 ring-blue-400 shadow-sm'
                    : isAnswered
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Question Area */}
      <main className="max-w-4xl w-full mx-auto p-4 sm:p-6 space-y-4 flex-1 safe-bottom-content pb-36 sm:pb-28">
        {/* Optional Paragraph / Comprehension Reading */}
        {currentQ.passage_text && currentQ.passage_text.trim() && (
          <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-4 sm:p-5 space-y-2.5 shadow-xs">
            <div className="flex items-center gap-2 text-xs font-bold text-[#1E3A8A] uppercase tracking-wider">
              <BookOpen className="w-4 h-4" />
              <span>Read the paragraph/poem and answer the question:</span>
            </div>
            <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-line border-t border-blue-200/60 pt-2 font-medium">
              {currentQ.passage_text}
            </div>
          </div>
        )}

        {/* Question Card */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between gap-2">
            <span className="bg-[#1E3A8A] text-white text-xs font-bold px-3 py-1 rounded-md">
              Question {currentIndex + 1}
            </span>
            <span className="text-xs text-slate-500 font-medium">
              {selectedAnswers.size} of {questions.length} answered
            </span>
          </div>

          {/* Optional Question Diagram Image */}
          {currentQ.image_url && (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-50 max-h-72 flex items-center justify-center group">
              <img
                src={currentQ.image_url}
                alt="Question Diagram"
                className="max-h-72 w-auto object-contain cursor-pointer"
                onClick={() => setZoomedImageUrl(currentQ.image_url || null)}
              />
              <button
                onClick={() => setZoomedImageUrl(currentQ.image_url || null)}
                className="absolute bottom-2 right-2 bg-black/60 hover:bg-black/80 text-white p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 backdrop-blur-xs transition-colors"
              >
                <ZoomIn className="w-3.5 h-3.5" />
                <span>Zoom</span>
              </button>
            </div>
          )}

          {/* Question Text */}
          <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed whitespace-pre-line">
            {currentQ.question_text}
          </h2>
        </div>

        {/* MCQ Options */}
        <div className="space-y-2.5">
          {[
            { letter: 'A', text: currentQ.option_a },
            { letter: 'B', text: currentQ.option_b },
            { letter: 'C', text: currentQ.option_c },
            { letter: 'D', text: currentQ.option_d },
          ].map(({ letter, text }) => {
            const isSelected = selectedOpt === letter;
            return (
              <div
                key={letter}
                onClick={() => handleSelectOption(qId, letter)}
                className={`p-4 rounded-xl border-2 transition-all flex items-center gap-3.5 cursor-pointer shadow-2xs ${
                  isSelected
                    ? 'bg-blue-50/80 border-[#1E3A8A] shadow-xs'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-colors ${
                    isSelected ? 'bg-[#1E3A8A] text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {letter}
                </div>
                <div className="text-sm sm:text-base text-slate-800 font-medium flex-1 leading-snug">
                  {text}
                </div>
              </div>
            );
          })}

          {/* Clear Selection */}
          {selectedOpt && (
            <div className="text-right pt-1">
              <button
                type="button"
                onClick={() => handleClearSelection(qId)}
                className="text-xs text-amber-600 hover:text-amber-700 font-bold underline cursor-pointer"
              >
                Clear Selection
              </button>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Sticky Action Bar - elevated safely above gesture bar & bottom bezel */}
      <footer className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 px-4 pt-3.5 pb-7 sm:pb-4 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] z-30 safe-bottom-footer">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <button
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="flex-1 max-w-[140px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm border border-slate-300 disabled:opacity-40 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Prev</span>
          </button>

          {currentIndex < questions.length - 1 ? (
            <button
              onClick={handleNext}
              className="flex-1 bg-[#1E3A8A] hover:bg-blue-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm shadow-xs transition-all flex items-center justify-center gap-1.5 active:scale-[0.99] cursor-pointer"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={() => {
                SoundManager.playButtonClick();
                setShowSubmitModal(true);
              }}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm shadow-xs transition-all flex items-center justify-center gap-1.5 active:scale-[0.99] cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Submit Test</span>
            </button>
          )}

          {/* Quick Submit Test button on all questions */}
          <button
            onClick={() => {
              SoundManager.playButtonClick();
              setShowSubmitModal(true);
            }}
            className="hidden sm:flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs sm:text-sm shadow-xs transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Submit ({selectedAnswers.size}/{questions.length})</span>
          </button>
        </div>
      </footer>

      {/* Submit Confirmation Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Submit Test?</h3>
            <div className="space-y-2 text-xs text-slate-700">
              <div className="flex justify-between p-2 rounded-lg bg-slate-50">
                <span className="font-medium text-slate-600">Total Questions:</span>
                <span className="font-bold">{questions.length}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-emerald-50 text-emerald-800">
                <span className="font-semibold">Answered:</span>
                <span className="font-bold">{selectedAnswers.size}</span>
              </div>
              {questions.length - selectedAnswers.size > 0 && (
                <div className="flex justify-between p-2 rounded-lg bg-amber-50 text-amber-800">
                  <span className="font-semibold">Unanswered:</span>
                  <span className="font-bold">{questions.length - selectedAnswers.size}</span>
                </div>
              )}
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Are you sure you want to finish? Your score will be saved immediately to the dashboard.
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowSubmitModal(false);
                  handleFinalSubmit();
                }}
                disabled={isSubmitting}
                className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                {isSubmitting ? (
                  <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                ) : (
                  <span>Confirm Submit</span>
                )}
              </button>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowSubmitModal(false);
                }}
                disabled={isSubmitting}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
              >
                Continue Test
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Exit Test Modal */}
      {showExitModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Exit Test?</h3>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              If you exit now, your current answers and timer progress will not be saved. Are you sure you want to return to dashboard?
            </p>
            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowExitModal(false);
                  onCancelTest();
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs shadow transition-all cursor-pointer"
              >
                Exit Test
              </button>
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowExitModal(false);
                }}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-xs transition-all cursor-pointer"
              >
                Stay
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Zoom Modal */}
      {zoomedImageUrl && (
        <div
          onClick={() => setZoomedImageUrl(null)}
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-xs"
        >
          <div className="relative max-w-2xl w-full bg-white rounded-2xl p-4 overflow-hidden">
            <button
              onClick={() => setZoomedImageUrl(null)}
              className="absolute top-3 right-3 bg-slate-100 text-slate-700 p-2 rounded-full hover:bg-slate-200 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={zoomedImageUrl}
              alt="Zoomed Question Diagram"
              className="w-full max-h-[80vh] object-contain mx-auto"
            />
          </div>
        </div>
      )}

      {/* Submit Error Modal with Retry */}
      {submitErrorMessage && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-red-200 space-y-4">
            <div className="flex items-center gap-2 text-red-600 font-bold">
              <AlertTriangle className="w-5 h-5" />
              <span>Submission Failed</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {submitErrorMessage}
            </p>
            <button
              onClick={handleFinalSubmit}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs shadow transition-all cursor-pointer"
            >
              Retry Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
