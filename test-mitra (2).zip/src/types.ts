export interface User {
  id?: number;
  name?: string | null;
  mobile_number: string;
  password?: string | null;
  role: string; // 'student' | 'admin' | 'teacher'
  device_id?: string | null;
  is_super_admin?: boolean | null;
}

export interface TestItem {
  id?: number;
  test_name: string;
  duration: number; // in minutes
  is_active?: boolean;
  created_at?: string | null;
  total_marks?: number | null;
  test_date?: string | null;
  test_day?: string | null;
}

export interface QuestionItem {
  id?: number;
  test_id: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  image_url?: string | null;
  passage_text?: string | null;
}

export interface PassageItem {
  id?: number;
  question_id?: number | null;
  passage?: string | null;
  passage_text?: string | null;
  content?: string | null;
}

export interface ResultItem {
  id?: number;
  user_id: number;
  test_id: number;
  score: number;
  created_at?: string | null;
  answers_json?: string | null;
}

export interface EnrichedResult {
  id?: number;
  userId: number;
  userMobile: string;
  testId: number;
  testName: string;
  testDuration: number;
  score: number;
  createdAt?: string | null;
  totalQuestions?: number;
  correctCount?: number;
  studentName?: string | null;
}

export interface ResultModel {
  id: string;
  testId: string;
  studentName: string;
  score: number;
  totalMarks?: number | null;
  createdAt?: string | null;
}

export type AppDestination =
  | 'SPLASH'
  | 'LOGIN'
  | 'STUDENT_HOME'
  | 'ADMIN_HOME'
  | 'TAKE_TEST'
  | 'TEST_RESULT';
