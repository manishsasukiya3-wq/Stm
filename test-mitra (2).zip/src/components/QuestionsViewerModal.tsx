import React, { useState } from 'react';
import { X, Edit2, Trash2, BookOpen } from 'lucide-react';
import { TestItem, QuestionItem } from '../types';
import { SoundManager } from '../services/soundManager';
import { ConfirmDeleteModal } from './ConfirmDeleteModal';

interface QuestionsViewerModalProps {
  test: TestItem;
  seqNum: number;
  questions: QuestionItem[];
  isLoading: boolean;
  isSuperAdmin?: boolean;
  onClose: () => void;
  onEditQuestion: (question: QuestionItem) => void;
  onDeleteQuestion: (questionId: number) => Promise<void>;
}

export const QuestionsViewerModal: React.FC<QuestionsViewerModalProps> = ({
  test,
  seqNum,
  questions,
  isLoading,
  isSuperAdmin = true,
  onClose,
  onEditQuestion,
  onDeleteQuestion,
}) => {
  const [questionToDelete, setQuestionToDelete] = useState<{
    id: number;
    index: number;
    text: string;
  } | null>(null);
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-7 max-h-[88vh] flex flex-col shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100 flex-shrink-0">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="bg-[#1E3A8A] text-white text-xs font-bold px-2.5 py-0.5 rounded-md">
                Test {seqNum}
              </span>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                {test.test_name}
              </h3>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Total Questions: {questions.length}
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Question List */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          {isLoading ? (
            <div className="py-16 text-center">
              <div className="w-8 h-8 rounded-full border-3 border-blue-200 border-t-[#1E3A8A] animate-spin mx-auto mb-2" />
              <p className="text-xs text-slate-500">Loading questions from Supabase...</p>
            </div>
          ) : questions.length === 0 ? (
            <div className="py-16 text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                <BookOpen className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-700">No questions in this test yet</p>
              <p className="text-xs text-slate-500">
                Go to &apos;+ Create / Add&apos; tab to add questions to this test.
              </p>
            </div>
          ) : (
            questions.map((q, idx) => (
              <div
                key={q.id || idx}
                className="p-4 sm:p-5 rounded-2xl border border-slate-200 bg-slate-50 space-y-3 shadow-2xs hover:border-slate-300 transition-colors"
              >
                {/* Question Header: Badge on left, Edit & Delete buttons on right */}
                <div className="flex justify-between items-center">
                  <span className="bg-[#1E3A8A] text-white text-xs font-bold px-3 py-1 rounded-md">
                    Question {idx + 1}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        SoundManager.playButtonClick();
                        onEditQuestion(q);
                      }}
                      className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit Question"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {isSuperAdmin && (
                      <button
                        type="button"
                        onClick={() => {
                          SoundManager.playButtonClick();
                          setQuestionToDelete({
                            id: q.id || 0,
                            index: idx + 1,
                            text: q.question_text,
                          });
                        }}
                        className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                        title="Delete Question"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Paragraph / Poem Box (Screenshot 2) */}
                {q.passage_text && (
                  <div className="bg-blue-50/80 border border-blue-200/80 rounded-xl p-3.5 space-y-1">
                    <h6 className="text-xs font-bold text-blue-900">
                      Read the paragraph/poem and answer the questions.
                    </h6>
                    <p className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed">
                      {q.passage_text}
                    </p>
                  </div>
                )}

                {/* Question Text */}
                <h5 className="text-sm font-bold text-slate-900 leading-snug">
                  {q.question_text}
                </h5>

                {/* Diagram Image if present */}
                {q.image_url && (
                  <div className="border border-slate-200 rounded-xl p-2 bg-white flex justify-center">
                    <img
                      src={q.image_url}
                      alt="Question Diagram"
                      className="max-h-44 object-contain rounded-lg"
                    />
                  </div>
                )}

                {/* Options Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                  <div
                    className={`p-2.5 rounded-xl border transition-all ${
                      q.correct_option === 'A'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    (A) {q.option_a}
                  </div>
                  <div
                    className={`p-2.5 rounded-xl border transition-all ${
                      q.correct_option === 'B'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    (B) {q.option_b}
                  </div>
                  <div
                    className={`p-2.5 rounded-xl border transition-all ${
                      q.correct_option === 'C'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    (C) {q.option_c}
                  </div>
                  <div
                    className={`p-2.5 rounded-xl border transition-all ${
                      q.correct_option === 'D'
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-700'
                    }`}
                  >
                    (D) {q.option_d}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer with Navy Blue Close Button */}
        <div className="pt-3 border-t border-slate-100 flex justify-center flex-shrink-0">
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="w-full sm:w-64 py-3 bg-[#1E3A8A] hover:bg-blue-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>

      {/* Warning Confirmation Modal for Question Deletion */}
      {questionToDelete && (
        <ConfirmDeleteModal
          title="Delete Question?"
          message={`Are you sure you want to delete Question ${questionToDelete.index}? This action cannot be undone.`}
          itemDetails={questionToDelete.text}
          confirmLabel="Delete Question"
          onConfirm={async () => {
            if (questionToDelete.id && onDeleteQuestion) {
              await onDeleteQuestion(questionToDelete.id);
            }
            setQuestionToDelete(null);
          }}
          onCancel={() => setQuestionToDelete(null)}
        />
      )}
    </div>
  );
};
