import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { SoundManager } from '../services/soundManager';

interface CalendarDatePickerModalProps {
  initialDate?: string; // Expects DD/MM/YYYY or YYYY-MM-DD
  onClose: () => void;
  onSelectDate: (formattedDate: string, dayOfWeek: string) => void;
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

const MONTH_SHORT = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sept',
  'Oct',
  'Nov',
  'Dec',
];

const DAY_NAMES = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const WEEKDAY_HEADER_LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

function parseInitialDate(dateStr?: string): Date {
  if (!dateStr || !dateStr.trim()) {
    return new Date();
  }
  const clean = dateStr.trim();
  // Check DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = clean.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (dmyMatch) {
    const day = parseInt(dmyMatch[1], 10);
    const month = parseInt(dmyMatch[2], 10) - 1;
    const year = parseInt(dmyMatch[3], 10);
    const parsed = new Date(year, month, day);
    if (!isNaN(parsed.getTime())) return parsed;
  }

  // Check YYYY-MM-DD
  const ymdMatch = clean.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
  if (ymdMatch) {
    const year = parseInt(ymdMatch[1], 10);
    const month = parseInt(ymdMatch[2], 10) - 1;
    const day = parseInt(ymdMatch[3], 10);
    const parsed = new Date(year, month, day);
    if (!isNaN(parsed.getTime())) return parsed;
  }

  const parsed = new Date(dateStr);
  return isNaN(parsed.getTime()) ? new Date() : parsed;
}

export const CalendarDatePickerModal: React.FC<CalendarDatePickerModalProps> = ({
  initialDate,
  onClose,
  onSelectDate,
}) => {
  const initial = parseInitialDate(initialDate);

  // Selected date components
  const [selectedYear, setSelectedYear] = useState<number>(initial.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(initial.getMonth()); // 0-indexed
  const [selectedDay, setSelectedDay] = useState<number>(initial.getDate());

  // Viewing month components (for browsing months without changing selection yet)
  const [viewYear, setViewYear] = useState<number>(initial.getFullYear());
  const [viewMonth, setViewMonth] = useState<number>(initial.getMonth());

  // Compute selected Date object for header display
  const selectedDateObj = new Date(selectedYear, selectedMonth, selectedDay);
  const dayOfWeekName = DAY_NAMES[selectedDateObj.getDay()];
  const dayOfWeekShort = DAY_SHORT[selectedDateObj.getDay()];
  const monthShort = MONTH_SHORT[selectedMonth];

  // Number of days in viewing month
  const daysInViewingMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  // First day of viewing month (0 = Sun, 1 = Mon, ..., 6 = Sat)
  const firstDayOfWeek = new Date(viewYear, viewMonth, 1).getDay();

  const handlePrevMonth = () => {
    SoundManager.playButtonClick();
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((prev) => prev - 1);
    } else {
      setViewMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    SoundManager.playButtonClick();
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((prev) => prev + 1);
    } else {
      setViewMonth((prev) => prev + 1);
    }
  };

  const handleDayClick = (day: number) => {
    SoundManager.playButtonClick();
    setSelectedDay(day);
    setSelectedMonth(viewMonth);
    setSelectedYear(viewYear);
  };

  const handleConfirm = () => {
    SoundManager.playButtonClick();
    // Format as DD/MM/YYYY
    const dd = String(selectedDay).padStart(2, '0');
    const mm = String(selectedMonth + 1).padStart(2, '0');
    const yyyy = selectedYear;
    const formatted = `${dd}/${mm}/${yyyy}`;
    const dayOfWeek = DAY_NAMES[new Date(selectedYear, selectedMonth, selectedDay).getDay()];

    onSelectDate(formatted, dayOfWeek);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-[328px] bg-[#2C2F36] rounded-[28px] shadow-2xl overflow-hidden border border-slate-700/50 flex flex-col text-white select-none animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Ribbon (Android/Material DatePicker style as in screenshot) */}
        <div className="px-6 pt-5 pb-4 bg-[#2C2F36]">
          <div className="text-slate-300 text-sm font-medium tracking-wide">
            {selectedYear}
          </div>
          <div className="text-white text-3xl sm:text-4xl font-semibold tracking-normal mt-0.5">
            {dayOfWeekShort}, {selectedDay} {monthShort}
          </div>
        </div>

        {/* Calendar Body */}
        <div className="px-5 py-3">
          {/* Month / Year Navigator */}
          <div className="flex items-center justify-between py-2 text-slate-200">
            <button
              type="button"
              onClick={handlePrevMonth}
              aria-label="Previous Month"
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <span className="text-sm font-semibold tracking-wide text-slate-100">
              {MONTH_NAMES[viewMonth]} {viewYear}
            </span>

            <button
              type="button"
              onClick={handleNextMonth}
              aria-label="Next Month"
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Weekday Letters Row (S M T W T F S) */}
          <div className="grid grid-cols-7 gap-1 mt-2 text-center text-xs font-semibold text-slate-400">
            {WEEKDAY_HEADER_LETTERS.map((letter, idx) => (
              <div key={idx} className="h-7 flex items-center justify-center">
                {letter}
              </div>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1 mt-1">
            {/* Blank offset placeholders */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`blank-${i}`} className="w-9 h-9" />
            ))}

            {/* Month Days */}
            {Array.from({ length: daysInViewingMonth }).map((_, i) => {
              const dayNum = i + 1;
              const isSelected =
                dayNum === selectedDay &&
                viewMonth === selectedMonth &&
                viewYear === selectedYear;

              return (
                <button
                  key={`day-${dayNum}`}
                  type="button"
                  onClick={() => handleDayClick(dayNum)}
                  className={`w-9 h-9 mx-auto rounded-full flex items-center justify-center text-sm transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-100 text-slate-900 font-bold shadow-md'
                      : 'text-slate-200 hover:bg-white/10 font-medium'
                  }`}
                >
                  {dayNum}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Actions Row (Cancel / OK) */}
        <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-slate-700/40">
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="px-4 py-2 text-sm font-semibold text-slate-300 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            className="px-5 py-2 text-sm font-bold text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};
