import React, { useState } from 'react';
import { Calendar, ChevronDown, X } from 'lucide-react';
import { TestItem } from '../types';
import { SoundManager } from '../services/soundManager';
import { CalendarDatePickerModal } from './CalendarDatePickerModal';

interface EditTestModalProps {
  test: TestItem;
  onClose: () => void;
  onSave: (testId: number, name: string, duration: number, date?: string | null, day?: string | null) => Promise<void>;
}

const DAYS_OF_WEEK = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

export const EditTestModal: React.FC<EditTestModalProps> = ({ test, onClose, onSave }) => {
  const [testName, setTestName] = useState(test.test_name);
  const [duration, setDuration] = useState(String(test.duration || 15));
  const [testDate, setTestDate] = useState(test.test_date || '');
  const [testDay, setTestDay] = useState(test.test_day || '');
  const [showDayDropdown, setShowDayDropdown] = useState(false);
  const [showCalendarDatePicker, setShowCalendarDatePicker] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    SoundManager.playButtonClick();
    if (!testName.trim()) {
      SoundManager.playError();
      return;
    }

    setIsSaving(true);
    await onSave(
      test.id || 0,
      testName.trim(),
      parseInt(duration) || 15,
      testDate.trim() || null,
      testDay.trim() || null
    );
    setIsSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-900">Edit Test</h3>
          <button
            type="button"
            onClick={() => {
              SoundManager.playButtonClick();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Test Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Test Name
            </label>
            <input
              type="text"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              placeholder="Test Name"
              required
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
            />
          </div>

          {/* Duration */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Duration (Minutes)
            </label>
            <input
              type="number"
              min="1"
              max="300"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              required
              className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A]"
            />
          </div>

          {/* Test Date with Calendar Icon */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Test Date (DD/MM/YYYY)
            </label>
            <div className="relative">
              <input
                type="text"
                value={testDate}
                onChange={(e) => setTestDate(e.target.value)}
                onClick={() => setShowCalendarDatePicker(true)}
                placeholder="DD/MM/YYYY"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 pr-11 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] cursor-pointer"
              />
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowCalendarDatePicker(true);
                }}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-[#1E3A8A] transition-colors cursor-pointer"
                title="Open Calendar"
              >
                <Calendar className="w-5 h-5 text-[#1E3A8A]" />
              </button>
            </div>
          </div>

          {/* Test Day Dropdown */}
          <div className="space-y-1 relative">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Test Day (e.g. Sunday)
            </label>
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  SoundManager.playButtonClick();
                  setShowDayDropdown(!showDayDropdown);
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-left text-sm font-semibold text-slate-900 flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-[#1E3A8A] cursor-pointer"
              >
                <span>{testDay || 'Select Day'}</span>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </button>

              {showDayDropdown && (
                <div className="absolute z-20 top-full mt-1 w-full bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden py-1 max-h-48 overflow-y-auto">
                  {DAYS_OF_WEEK.map((day) => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => {
                        SoundManager.playButtonClick();
                        setTestDay(day);
                        setShowDayDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-2.5 text-xs font-bold transition-colors cursor-pointer ${
                        testDay === day
                          ? 'bg-blue-50 text-[#1E3A8A]'
                          : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Buttons: Cancel & Save Changes */}
          <div className="flex items-center gap-3 pt-3">
            <button
              type="button"
              onClick={() => {
                SoundManager.playButtonClick();
                onClose();
              }}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 py-3 px-4 rounded-xl bg-[#1E3A8A] hover:bg-blue-800 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              {isSaving ? (
                <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>

      {showCalendarDatePicker && (
        <CalendarDatePickerModal
          initialDate={testDate}
          onClose={() => setShowCalendarDatePicker(false)}
          onSelectDate={(formattedDate, dayOfWeek) => {
            setTestDate(formattedDate);
            if (dayOfWeek) {
              setTestDay(dayOfWeek);
            }
          }}
        />
      )}
    </div>
  );
};
