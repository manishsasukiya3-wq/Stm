/**
 * Utility to initialize safe area insets for Android APKs, WebViews, and Notch devices.
 * Automatically adapts on all mobile devices to avoid top notch/status bar
 * and bottom navigation/gesture bar collisions.
 */
export function initSafeAreaInsets(): void {
  if (typeof window === 'undefined') return;

  const updateInsets = () => {
    const isMobileScreen = window.innerWidth < 768;
    const ua = navigator.userAgent || '';
    const isMobileDevice =
      /Android|iPhone|iPad|iPod|Mobile/i.test(ua) ||
      'ontouchstart' in window ||
      navigator.maxTouchPoints > 0;

    if (isMobileScreen || isMobileDevice) {
      // Ensure at least 36px on top for Android status bar / notch
      document.documentElement.style.setProperty(
        '--status-bar-pad',
        'max(env(safe-area-inset-top, 0px), 36px)'
      );
      // Ensure at least 24px on bottom for gesture navigation / 3-button bar
      document.documentElement.style.setProperty(
        '--nav-bottom-pad',
        'max(env(safe-area-inset-bottom, 0px), 24px)'
      );
    } else {
      document.documentElement.style.setProperty(
        '--status-bar-pad',
        'env(safe-area-inset-top, 0px)'
      );
      document.documentElement.style.setProperty(
        '--nav-bottom-pad',
        'env(safe-area-inset-bottom, 0px)'
      );
    }
  };

  updateInsets();
  window.addEventListener('resize', updateInsets);
  window.addEventListener('orientationchange', updateInsets);
}

